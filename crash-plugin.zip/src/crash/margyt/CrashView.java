package crash.margyt;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

/**
 * Прозрачный слой с кнопкой. Тап по кнопке запускает лавину окон с ошибками,
 * через несколько секунд приложение закрывается. Повторный тап по кнопке во время
 * лавины отменяет всё. Касания мимо кнопки проходят в приложение, пока лавина не идёт.
 */
final class CrashView extends View {

    interface Logger {
        void log(String s);
    }

    private static final int IDLE = 0, SPAWN = 1, BLACK = 2;
    private static final long SPAWN_MS = 7000L;
    private static final long BLACK_MS = 900L;
    private static final int MAX_WINS = 160;

    private static final String[] RU_TITLE = {"Ошибка", "Критическая ошибка", "Предупреждение", "Системное окно", "Сбой"};
    private static final String[] EN_TITLE = {"Error", "Critical error", "Warning", "System window", "Failure"};
    private static final String[] RU_MSG = {
            "Приложение не отвечает", "Недостаточно памяти", "Ошибка 0x80070005", "Нарушение доступа",
            "Соединение потеряно", "Файл повреждён", "Неизвестная ошибка", "Процесс завершён с ошибкой",
            "Стек переполнен", "Сбой модуля ядра", "Не удалось продолжить", "Фатальное исключение"};
    private static final String[] EN_MSG = {
            "Application is not responding", "Out of memory", "Error 0x80070005", "Access violation",
            "Connection lost", "File is corrupted", "Unknown error", "Process exited with an error",
            "Stack overflow", "Kernel module failure", "Cannot continue", "Fatal exception"};

    private static final class Win {
        float x, y, w, h;
        int kind;
        String title, msg;
    }

    private final Logger logger;
    private final float dp;
    private final int slop;
    private final boolean ru;
    private final Random rnd = new Random();
    private final ArrayList<Win> wins = new ArrayList<Win>();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private boolean running;
    private int state = IDLE;
    private long stateT, lastFrame;
    private float spawnCarry;
    private boolean killed;

    // кнопка
    private float bx = -1f, by = -1f;
    private final float br;
    private boolean downOnBtn, dragging;
    private float downX, downY, offX, offY;

    private final Runnable stepper = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            try {
                step();
            } catch (Throwable t) {
                logger.log("crash: step failed: " + t);
            }
            postOnAnimation(this);
        }
    };

    CrashView(Context context, Logger logger) {
        super(context);
        this.logger = logger;
        this.dp = context.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.br = 24f * dp;
        this.ru = "ru".equals(Locale.getDefault().getLanguage());
        setWillNotDraw(false);
    }

    void destroy() {
        running = false;
        removeCallbacks(stepper);
        wins.clear();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (bx < 0f) {
            bx = w - 8f * dp - br;
            by = h * 0.40f;
        }
        bx = clamp(bx, br, w - br);
        by = clamp(by, br, h - br);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        lastFrame = SystemClock.uptimeMillis();
        removeCallbacks(stepper);
        postOnAnimation(stepper);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(stepper);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------ логика

    private void start() {
        wins.clear();
        spawnCarry = 0f;
        state = SPAWN;
        stateT = SystemClock.uptimeMillis();
        logger.log("crash: started avalanche");
    }

    private void cancel() {
        state = IDLE;
        wins.clear();
        logger.log("crash: cancelled");
    }

    private void step() {
        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        if (state == SPAWN) {
            long t = now - stateT;
            if (t >= SPAWN_MS) {
                state = BLACK;
                stateT = now;
            } else {
                float k = t / (float) SPAWN_MS;
                float rate = 2f + 38f * k * k;
                spawnCarry += rate * dt;
                while (spawnCarry >= 1f) {
                    spawnCarry -= 1f;
                    addWin(w, h);
                }
            }
        } else if (state == BLACK) {
            if (now - stateT >= BLACK_MS && !killed) {
                killed = true;
                logger.log("crash: bye");
                try {
                    android.os.Process.killProcess(android.os.Process.myPid());
                } catch (Throwable ignored) {
                }
                System.exit(10);
            }
        }
        if (state != IDLE) invalidate();
        else if (!wins.isEmpty()) {
            wins.clear();
            invalidate();
        }
    }

    private void addWin(int sw, int sh) {
        Win win = new Win();
        win.w = (170f + rnd.nextFloat() * 110f) * dp;
        if (win.w > sw * 0.85f) win.w = sw * 0.85f;
        win.h = (96f + rnd.nextFloat() * 40f) * dp;
        win.x = rnd.nextFloat() * (sw - win.w);
        win.y = rnd.nextFloat() * (sh - win.h);
        win.kind = rnd.nextInt(3);
        win.title = pick(ru ? RU_TITLE : EN_TITLE);
        win.msg = pick(ru ? RU_MSG : EN_MSG);
        wins.add(win);
        if (wins.size() > MAX_WINS) wins.remove(0);
    }

    private String pick(String[] a) {
        return a[rnd.nextInt(a.length)];
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    // ------------------------------------------------------------ рисование

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        if (state == BLACK) {
            fill.setColor(0xFF000000);
            c.drawRect(0f, 0f, w, h, fill);
            return;
        }

        if (state == SPAWN) {
            float shake = Math.min(1f, (SystemClock.uptimeMillis() - stateT) / (float) SPAWN_MS);
            float j = shake * shake * 5f * dp;
            c.save();
            c.translate((rnd.nextFloat() - 0.5f) * j, (rnd.nextFloat() - 0.5f) * j);
            for (int i = 0; i < wins.size(); i++) drawWin(c, wins.get(i));
            c.restore();
        }
        drawButton(c);
    }

    private void drawWin(Canvas c, Win win) {
        // тень
        fill.setColor(0x55000000);
        rect.set(win.x + 4f * dp, win.y + 4f * dp, win.x + win.w + 4f * dp, win.y + win.h + 4f * dp);
        c.drawRect(rect, fill);
        // фон
        fill.setColor(0xFFECECEC);
        rect.set(win.x, win.y, win.x + win.w, win.y + win.h);
        c.drawRect(rect, fill);
        // заголовок
        int bar = win.kind == 0 ? 0xFFC62828 : (win.kind == 1 ? 0xFFE0A100 : 0xFF1B4FBF);
        fill.setColor(bar);
        rect.set(win.x, win.y, win.x + win.w, win.y + 22f * dp);
        c.drawRect(rect, fill);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(12f * dp);
        text.setTextAlign(Paint.Align.LEFT);
        text.setFakeBoldText(true);
        c.drawText(win.title, win.x + 8f * dp, win.y + 15f * dp, text);
        // крестик
        fill.setColor(0xFFE53935);
        rect.set(win.x + win.w - 22f * dp, win.y, win.x + win.w, win.y + 22f * dp);
        c.drawRect(rect, fill);
        text.setTextAlign(Paint.Align.CENTER);
        c.drawText("X", win.x + win.w - 11f * dp, win.y + 15f * dp, text);
        // значок
        fill.setColor(bar);
        c.drawCircle(win.x + 22f * dp, win.y + 50f * dp, 11f * dp, fill);
        text.setTextSize(15f * dp);
        c.drawText(win.kind == 1 ? "!" : (win.kind == 0 ? "X" : "i"), win.x + 22f * dp, win.y + 55f * dp, text);
        // текст
        text.setColor(0xFF222222);
        text.setFakeBoldText(false);
        text.setTextSize(11.5f * dp);
        text.setTextAlign(Paint.Align.LEFT);
        c.drawText(win.msg, win.x + 40f * dp, win.y + 54f * dp, text);
        // кнопка OK
        fill.setColor(0xFFD0D0D0);
        rect.set(win.x + win.w / 2f - 24f * dp, win.y + win.h - 26f * dp,
                win.x + win.w / 2f + 24f * dp, win.y + win.h - 8f * dp);
        c.drawRect(rect, fill);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(11f * dp);
        c.drawText("OK", win.x + win.w / 2f, win.y + win.h - 13f * dp, text);
    }

    private void drawButton(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float pulse = state == IDLE ? 0f : 0.5f + 0.5f * (float) Math.sin(now / 90.0);
        fill.setColor(0x55000000);
        c.drawCircle(bx + 1.5f * dp, by + 2.5f * dp, br, fill);
        fill.setColor(state == IDLE ? 0xFFD32F2F : (pulse > 0.5f ? 0xFFFF5252 : 0xFF8E0000));
        c.drawCircle(bx, by, br, fill);
        fill.setColor(0xFFFFFFFF);
        c.drawCircle(bx, by, br - 4f * dp, fill);
        fill.setColor(state == IDLE ? 0xFFD32F2F : 0xFF8E0000);
        c.drawCircle(bx, by, br - 7f * dp, fill);
        text.setColor(0xFFFFFFFF);
        text.setFakeBoldText(true);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(24f * dp);
        c.drawText("!", bx, by + 8.5f * dp, text);
    }

    // ------------------------------------------------------------ касания

    private boolean onButton(float x, float y) {
        float dx = x - bx, dy = y - by, r = br + 8f * dp;
        return dx * dx + dy * dy <= r * r;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        try {
            float x = e.getRawX(), y = e.getRawY();
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            x -= loc[0];
            y -= loc[1];
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (state == BLACK) return true;
                    if (onButton(x, y)) {
                        downOnBtn = true;
                        dragging = false;
                        downX = x;
                        downY = y;
                        offX = bx - x;
                        offY = by - y;
                        return true;
                    }
                    downOnBtn = false;
                    // во время лавины касания гасим, как будто всё зависло
                    return state == SPAWN;
                case MotionEvent.ACTION_MOVE:
                    if (downOnBtn) {
                        if (!dragging && (Math.abs(x - downX) > slop || Math.abs(y - downY) > slop)) dragging = true;
                        if (dragging) {
                            bx = clamp(x + offX, br, getWidth() - br);
                            by = clamp(y + offY, br, getHeight() - br);
                            invalidate();
                        }
                        return true;
                    }
                    return state == SPAWN;
                case MotionEvent.ACTION_UP:
                    if (downOnBtn) {
                        downOnBtn = false;
                        if (!dragging) {
                            if (state == IDLE) start();
                            else if (state == SPAWN) cancel();
                        }
                        dragging = false;
                        invalidate();
                        return true;
                    }
                    return state == SPAWN;
                case MotionEvent.ACTION_CANCEL:
                    downOnBtn = false;
                    dragging = false;
                    return true;
                default:
                    return downOnBtn || state == SPAWN;
            }
        } catch (Throwable t) {
            logger.log("crash: touch failed: " + t);
            return false;
        }
    }
}
