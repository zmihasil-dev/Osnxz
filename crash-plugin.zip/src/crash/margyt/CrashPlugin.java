package crash.margyt;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;

import cat.narezany.margyt.plugin.MargyPlugin;
import cat.narezany.margyt.plugin.PluginContext;

/** Вылет: кнопка, лавина окон с ошибками, потом приложение закрывается. */
public final class CrashPlugin extends MargyPlugin {

    private Handler main;
    private PluginContext pc;
    private CrashView view;

    @Override
    public void onStart(Context context) {
        final Context ctx = context;
        try {
            pc = margyt();
        } catch (Throwable ignored) {
        }
        main = new Handler(Looper.getMainLooper());
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    view = new CrashView(ctx, new CrashView.Logger() {
                        @Override
                        public void log(String s) {
                            safeLog(s);
                        }
                    });
                    safeLog("crash: started");
                } catch (Throwable t) {
                    safeLog("crash: start failed: " + t);
                }
            }
        });
    }

    @Override
    public void onActivityResumed(final Activity activity) {
        if (main == null) return;
        main.post(new Runnable() {
            @Override
            public void run() {
                attach(activity);
            }
        });
    }

    @Override
    public void onActivityPaused(final Activity activity) {
        if (main == null) return;
        main.post(new Runnable() {
            @Override
            public void run() {
                detach(activity);
            }
        });
    }

    @Override
    public void onStop() {
        if (main == null) return;
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (view != null) {
                        removeFromParent();
                        view.destroy();
                        view = null;
                    }
                } catch (Throwable t) {
                    safeLog("crash: stop failed: " + t);
                }
            }
        });
    }

    private void attach(Activity activity) {
        try {
            if (view == null) return;
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            if (view.getParent() == decor) {
                view.bringToFront();
                return;
            }
            removeFromParent();
            decor.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            view.bringToFront();
        } catch (Throwable t) {
            safeLog("crash: attach failed: " + t);
        }
    }

    private void detach(Activity activity) {
        try {
            if (view == null) return;
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            if (view.getParent() == decor) {
                decor.removeView(view);
            }
        } catch (Throwable t) {
            safeLog("crash: detach failed: " + t);
        }
    }

    private void removeFromParent() {
        ViewParent p = view.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(view);
    }

    private void safeLog(String s) {
        try {
            if (pc != null) pc.log(s);
        } catch (Throwable ignored) {
        }
    }
}
