package cat.narezany.margyt.plugin;

import android.content.Context;
import android.content.SharedPreferences;

public class PluginContext {
    public Context context() { return null; }
    public SharedPreferences prefs() { return null; }
    public void log(String s) {}
}
