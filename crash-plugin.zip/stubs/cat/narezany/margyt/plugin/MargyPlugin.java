package cat.narezany.margyt.plugin;

import android.app.Activity;
import android.content.Context;

public abstract class MargyPlugin {
    public MargyPlugin() {}
    public PluginContext margyt() { return null; }
    public void onStart(Context context) {}
    public void onStop() {}
    public void onActivityResumed(Activity activity) {}
    public void onActivityPaused(Activity activity) {}
}
