#!/bin/bash
# Сборка crash.mtp. Нужны: JDK 8+, Android SDK (platforms/android-XX/android.jar и build-tools/XX/d8).
set -e
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Задай ANDROID_HOME (путь к Android SDK)}"
ANDROID_JAR=$(ls -d "$ANDROID_HOME"/platforms/android-*/android.jar | sort -V | tail -1)
D8=$(ls -d "$ANDROID_HOME"/build-tools/*/d8 | sort -V | tail -1)
rm -rf build out
mkdir -p build/api build/classes out
# заглушки API мода (в .mtp НЕ попадают, реальные классы есть в самом моде)
javac -nowarn --release 8 -cp "$ANDROID_JAR" -d build/api $(find stubs/cat -name '*.java')
javac -nowarn -encoding UTF-8 --release 8 -cp "$ANDROID_JAR:build/api" -d build/classes src/crash/margyt/*.java
"$D8" --release --min-api 23 --lib "$ANDROID_JAR" --output out $(find build/classes -name '*.class')
cp manifest.json icon.png out/
(cd out && rm -f ../crash.mtp && zip -q -X ../crash.mtp manifest.json classes.dex icon.png)
echo "Готово: $(pwd)/crash.mtp"
